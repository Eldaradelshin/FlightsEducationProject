//
//  FavoriteTicket+CoreDataClass.h
//  
//
//  Created by rushan adelshin on 10.03.2018.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

NS_ASSUME_NONNULL_BEGIN

@interface FavoriteTicket : NSManagedObject

@end

NS_ASSUME_NONNULL_END

#import "FavoriteTicket+CoreDataProperties.h"
