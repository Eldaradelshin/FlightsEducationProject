//
//  FavoriteTicket+CoreDataClass.m
//  
//
//  Created by rushan adelshin on 10.03.2018.
//
//

#import "FavoriteTicket+CoreDataClass.h"

@implementation FavoriteTicket

@end
