//
//  MapViewController.h
//  L1-TestProject
//
//  Created by rushan adelshin on 08.03.2018.
//  Copyright © 2018 Eldar Adelshin. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "DataManager.h"

@interface MapViewController : UIViewController

@end
